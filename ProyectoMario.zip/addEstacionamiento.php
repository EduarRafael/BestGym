<?php
//including the database connection file
include_once("base_de_datos.php");
    
    //Tomo las variables que envio el formulario anterior para asi poder hacer el select y el update de la tabla
    $esta =  "Si";
    $tipo = $_POST['tipo'];
    $tiempo =  $_POST['tiempoEst'];
    $finale = $tiempo ." ".$tipo;
    if($tipo=="Dias"){
	    $pago= $tiempo*20;
	}else if(tipo=="Horas"){
	    $pago= $tiempo*30;
	}
    $id = $_POST['id'];
        //Se prepara la setencia de edit para poder modificar los datos de la tabla
    	$sentencia=$BD->prepare("UPDATE users SET estacionamiento=?,tiempoestacionamiento=? WHERE id=?;");
    	//Se executa la sentencia para poder enviar los datos a la tabla con los parametros en los corchetes
    	$resultado = $sentencia->execute([$esta,$finale,$id]);
    	
        //Se "Inserta" un valor en la tabla null, para que este realize un AI del id de la tabla
        $sentencia=$BD->prepare("INSERT INTO tickets(total)VALUES(?)");
        $resultado = $sentencia->execute([$pago]);
        $sentencia2=$BD->query("SELECT * FROM tickets ORDER BY id DESC LIMIT 1");
        $resultado2 = $sentencia2->fetchAll(PDO::FETCH_OBJ);
	

?>
<!DOCTYPE html>
<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
    height: 100%;
    margin: 0;
}

.bg {

  /* The image used */
  background-image: url("Background/fondo2.jpg");
  background-attachment: fixed;
  font-style:italic;
  font-weight:bold;
  font-size:1.5em;
  font-color:#ffffff;
  font-family:'Helvetica','Verdana','Monaco',sans-serif;

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

{
    box-sizing: border-box;
}

.column {
    float: left;
    width: 33.33%;
    padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
    content: "";
    clear: both;
    display: table;
}
</style>
</head>
<body>

<div class="bg">
<nav class="navbar navbar-inverse">
<div class="container-fluid">
</ul></div></nav>
<!-- Coloca el numero de ticket para que el usario pueda ir a pagar a caja -->
<?php foreach ($resultado2 as $resultado2){ ?>
<a class="navbar-brand" ><h1>Su numero de ticket es #<?php echo $resultado2->id ?></h1></a>
<a class="navbar-brand" ><h1>El total a pagar es $<?php echo $pago ?>!</h1></a>
<a class="navbar-brand" href="vermiembros.php"><h1>Regresar!</h1></a>
<?php } ?>
</body>


</html>
 