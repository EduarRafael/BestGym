<?php
    include_once "base_de_datos.php";
    //Se toman las variables que envio el usario desde el formulario de inicio 
    $validacion = $_POST['user'];
    $validacion2= $_POST['contra'];
    //Se prepara la sentencia de sql
    $sql="SELECT * FROM users WHERE username= ? AND password=?";
    $sentencia=$BD->prepare($sql);
    //Se executa la sentencia de sql segun los parametros validacion y validaicon2
    $sentencia->execute([$validacion,$validacion2]);
    $resultado = $sentencia->fetchAll(PDO::FETCH_OBJ);
    if($resultado==null || empty($resultado)){
        header('Location: inicio.html');
    }
?>
<!doctype html>
<html lang="en">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet"/>
<link href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css" rel="stylesheet"/>


</head>
  <head>
    <style type="text/css">
    
    div.a {
    text-align: center;
}
.hidden {
    display: none;
}
      body {
        background:url(Background/fondo2.jpg) no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
      }
      .EstiloTexto{ 
    color:#3366ff; 
    font-weight: bold; 
    text-align: center; 
    font-family:Verdana, Arial, Helvetica, sans-serif; 
    font-size: 80px; 
} 

    </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

    <title>Bienvenido usuario!!</title>
  </head>
  <body>
    <nav class="navbar navbar-dark bg-dark">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href=""><h1>Bienvenido <?php foreach ($resultado as $resultado2){
        echo $resultado2->Nombre;
          }?>!</h1></a>
        
      </div>
    </nav>
    
    
<div class="a">
    <div class="container">
    <a class="navbar-brand" href=""><h1>Informacion del Usuario!</h1></a>
    <table class="table table-dark">
    <thead>
    <tr>
    <!--Imprimo en la pagina el nombre de los campos que se van a mostrar-->
    <h1><th>Membresia</th></h1>
    <h3><th>Fecha de ultimo pago</th></h3>
    <h3><th>Pagar antes de</th></h3>
    <h3><th>Estacionamiento</th></h3>
    <h3><th>Tiempo Restante</th></h3>
    </tr>
    </thead>
    <tbody>
    <!--Se reccore el array de resultados de la consulta-->    
    <?php foreach ($resultado as $resultado){ ?>
    <tr>
     <?php $var=$resultado->Nombre ?>   
    <h3><td><?php echo $resultado->membresia ?></td></h3>
    <h3><td><?php echo $resultado->fecha_ultimopago ?></td></h3>
    <h3><td><?php echo $resultado->fecha_vencimiento ?></td></h3>
    <h3><td><?php echo $resultado->estacionamiento ?></td></h3>
    <h3><td><?php echo $resultado->tiempoestacionamiento ?></td></h3>
    <!--Botones para pagar/renovar membresia-->
    <?php } ?>
    </tbody>
    </table>
    </div>
     <form method="post" action="pagarUsuario.php">
    <button type="submit" class="btn btn-danger" name="id" value="<?php echo htmlspecialchars($var); ?>">Hacer pago de membresia o estacionamiento!</button>
    </form>



  

    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.2/moment.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  </body>
</html>