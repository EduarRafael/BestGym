<?php
//including the database connection file
include_once("base_de_datos.php");
    $nombre = $_POST['Nombres'];
    $memb =  $_POST['membresia'];
    $fechaulti = date("Y-m-d");
    $now = time();
    //Creamos la variable WeekMon para poder sumarle los meses que el usario quiere pagar!
    $WeekMon  = mktime(0, 0, 0, date("m", $now)+$memb  , date("d", $now), date("Y", $now));    //monday week begin calculation
    $todayh = getdate($WeekMon); //monday week begin reconvert

    //Se toman las variables de todayh para acomodar la fecha de vencimeitno
    $d = $todayh['mday'];
     $m = $todayh['mon'];
     $y = $todayh['year'];
    //Se acomoda el tipo de compra para estacionamiento con un espacio y el timpo 
   
    
	 //Se acomoda la fecha empezando por el año(y) y separandolo por "-"
    $fechaultima=$y."-".$m."-".$d;
	$estacion = $_POST['Estacionamiento'];
	$tipo = $_POST['tipo'];
	$tiempoEsta =$_POST['tiempoEst'];
	 $finale = $tiempoEsta ." ". $tipo;
	$user=$_POST['usr'];
	$pass=$_POST['pass'];
	if($tipo=="Dias"){
	    $pago= $memb*200+$tiempoEsta*20;
	}else if(tipo=="Horas"){
	    $pago= $memb*200+$tiempoEsta*30;
	}
	$membre = "Si";
	
    	$sentencia=$BD->prepare("INSERT INTO users(username,password,Nombre,membresia,fecha_ultimopago, fecha_vencimiento,estacionamiento,tiempoestacionamiento) VALUES(?,?,?,?,?,?,?,?)");
    	$resultado = $sentencia->execute([$user,$pass,$nombre,$membre,$fechaulti,$fechaultima,$estacion,$finale]);
		
		 $sentencia=$BD->prepare("INSERT INTO tickets(total)VALUES(?)");
        $resultado = $sentencia->execute([$pago]);
        $sentencia2=$BD->query("SELECT * FROM tickets ORDER BY id DESC LIMIT 1");
        $resultado2 = $sentencia2->fetchAll(PDO::FETCH_OBJ);
	

?>
<!DOCTYPE html>
<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
    height: 100%;
    margin: 0;
}

.bg {

  /* The image used */
  background-image: url("Background/fondo2.jpg");
  background-attachment: fixed;
  font-style:italic;
  font-weight:bold;
  font-size:1.5em;
  font-color:#ffffff;
  font-family:'Helvetica','Verdana','Monaco',sans-serif;

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

{
    box-sizing: border-box;
}

.column {
    float: left;
    width: 33.33%;
    padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
    content: "";
    clear: both;
    display: table;
}
</style>
</head>
<body>

<div class="bg">
<nav class="navbar navbar-inverse">
<div class="container-fluid">
</ul></div></nav>
<a class="navbar-brand" ><h1>Se registro el registro correctamente</h1></a>
<?php foreach ($resultado2 as $resultado2){ ?>
<a class="navbar-brand" ><h1>Su numero de ticket es #<?php echo $resultado2->id ?></h1></a>
<a class="navbar-brand" ><h1>El total a pagar es $<?php echo $pago ?>!</h1></a>
<?php } ?>
<a class="navbar-brand" href="nuevo_cliente.php"><h1>Regresar</h1></a>
</body>


</html>
 