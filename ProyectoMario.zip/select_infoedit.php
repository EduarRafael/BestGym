<?php
    include "base_de_datos.php";
    $validacion = $_POST['id'];
    $sentencia = $BD->prepare("SELECT * FROM users WHERE id=?");
    $sentencia->execute([$validacion]);
    $resultados = $sentencia->fetchAll(PDO::FETCH_OBJ);

?>
<!DOCTYPE html>
<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
    height: 100%;
    margin: 0;
}

div.a {
    text-align: center;
}

.center_div{
    margin: 10 auto;
    width:50% /* value of your choice which suits your alignment */
}

.bg {

  /* The image used */
  background-image: url("Background/landmark3.jpeg");
  background-attachment: fixed;
  font-style:italic;
  font-weight:bold;
  font-size:1.5em;
  font-color:#ffffff;
  font-family:'Helvetica','Verdana','Monaco',sans-serif;

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

</style>
</head>
<body>

<div class="bg">

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"></a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#"></a></li>
    </ul>
  </div>
</nav>

<br>
<br>
<br>
<br>


<form action="edit.php" method="post"> 
<div class="container center_div">
  <div class="form-row">
    <div class="col-md-4 mb-3">
     <?php foreach ($resultados as $resultados){ ?>   
      <label for="validationDefault01">Nombre</label>
      <input type="text" class="form-control" id="validationDefault01" placeholder="" name="Nombres" value="<?php echo $resultados->Nombre ?>" required>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault02">Membresia Activa</label>
      <input type="text" class="form-control" id="validationDefault02" placeholder=""  name="membresia" value="<?php echo $resultados->membresia ?>" required>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationDefault03">Fecha del ultimo pago</label>
      <input type="date" class="form-control" id="validationDefault03" placeholder="" name="fechaultimo" value="<?php echo $resultados->fecha_ultimopago ?>"  required>
      <br>
    </div>
    <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationDefault03">Fecha Vencimiento</label>
      <input type="date" class="form-control" id="validationDefault04" placeholder="" name="fechaven" value="<?php echo $resultados->fecha_vencimiento ?>" required>
      <br>
    </div>
    <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationDefault03">Tiene Estacionamiento</label>
      <input type="text" class="form-control" id="validationDefault05" placeholder="" name="Estacionamiento"  value="<?php echo $resultados->estacionamiento ?>" required>
      <br>
    </div>
    <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationDefault03">Tiempo Estacionamiento</label>
      <input type="text" class="form-control" id="validationDefault06" placeholder="" name="tiempoest" value="<?php echo $resultados->tiempoestacionamiento ?>" required>
    </div>
    <div hidden lass="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationDefault03">Tiempo Estacionamiento</label>
      <input type="text" class="form-control" id="validationDefault07" placeholder="" name="id" value="<?php echo $resultados->id ?>" required>
    </div>
     <?php } ?>
    <br>
    <br>
  </div></div>
  <br>
<div class="container center_div">
  <br><br><br>
  <button class="btn btn-primary" type="submit">Editar</button> 
</div>

</form>

</div>
</body>
</html>