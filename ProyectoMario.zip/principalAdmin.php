<?php
    include_once "base_de_datos.php";
    //Se toman las variables que envio el usario desde el formulario de inicio 
    $validacion = $_POST['user'];
    $validacion2= $_POST['contra'];
    //Se prepara la sentencia de sql
    $sql="SELECT * FROM admins WHERE usuario= ? AND contra=?";
    $sentencia=$BD->prepare($sql);
    //Se executa la sentencia de sql segun los parametros validacion y validaicon2
    $sentencia->execute([$validacion,$validacion2]);
    $resultado = $sentencia->fetchAll(PDO::FETCH_OBJ);
    if($resultado==null || empty($resultado)){
        header('Location: inicio.html');
    }
?>
<!doctype html>
<html lang="en">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet"/>
<link href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css" rel="stylesheet"/>


</head>
  <head>
    <style type="text/css">
    
    div.a {
    text-align: center;
}
.hidden {
    display: none;
}
      body {
        background:url(Background/fondo2.jpg) no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
      }
      .EstiloTexto{ 
    color:#3366ff; 
    font-weight: bold; 
    text-align: center; 
    font-family:Verdana, Arial, Helvetica, sans-serif; 
    font-size: 80px; 
} 

    </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

    <title>Bienvenido usuario!!</title>
  </head>
  <body>
    <nav class="navbar navbar-dark bg-dark">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href=""><h1>Bienvenido <?php foreach ($resultado as $resultado){
        echo $resultado->Nombre;
          }?>!</h1></a>
        </div>
        </div>
        </nav> 
<br>
<br>
<br>
 </center>
 <center>
<div class="row">
  <div class="container">
    <button class="button" type="button" style="width: 70%; border:none; display:inline-block; color:black;"><a href="nuevo_cliente.php">
    <h1>Registrar a un nuevo cliente!</h1>
    
    </button>
  </div>
</div>

<br>
<br>

<div class="row">
  <div class="container">
    <button class="button" type="button" style="width: 70%; border:none; display:inline-block; color:black;"><a href="vermiembros.php">
    <h1>Ver todos los clientes!(Hacer pagos en la membresia o estacionamiento)</h1>
    </button>
  </div>
</div>
<br>
<br>

<div class="row">
  <div class="container">
    <button class="button" type="button" style="width: 70%; border:none; display:inline-block; color:black;"><a href="ganancias.php">
    <h1>Ver ganancias totales!</h1>
    </button>
  </div>
</div>
<br>

</center>


  

    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.2/moment.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
  </body>
</html>