<?php
    include "base_de_datos.php";
    $validacion = $_POST['id'];
    $sentencia = $BD->prepare("SELECT * FROM users WHERE id=?");
    $sentencia->execute([$validacion]);
    $resultados = $sentencia->fetchAll(PDO::FETCH_OBJ);

?>
<!DOCTYPE html>

<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
    height: 100%;
    margin: 0;
}

div.a {
    text-align: center;
}

.center_div{
    margin: 10 auto;
    width:50% /* value of your choice which suits your alignment */
}

.bg {

  /* The image used */
  background-image: url("Background/fondo2.jpg");
  background-attachment: fixed;
  font-style:italic;
  font-weight:bold;
  font-size:1.5em;
  font-color:#ffffff;
  font-family:'Helvetica','Verdana','Monaco',sans-serif;

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

</style>
</head>
<body>

<div class="bg">

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
  </div>
</nav>

<br>
<br>
<br>
<br>


<form action="addEstacionamiento.php" method="post"> 
<div class="container center_div">
<?php foreach ($resultados as $resultados){ ?>   
  <div class="form-row">
    <div hidden class="col-md-4 mb-3">
      <label for=""></label>
      <input type="text" class="form-control" id="validationDefault01" placeholder="" name="id" value="<?php echo $resultados->id ?>" >
    </div>
    <?php } ?>
    <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationDefault03">Tiempo Estacionamiento</label>
      <input type="number" class="form-control" id="validationDefault05" placeholder="" name="tiempoEst" required>
    </div>
    <div class="form-row">
    <div class="col-md-6 mb-3">
    <div class="radio">
      <label><input type="radio" name="tipo" value="Dias" >Dias</label>
    </div>
    <div class="radio">
      <label><input type="radio" name="tipo" value="Horas" >Horas</label>
    </div>
    </div>
    </div>

 
  <br>
  <br>
  <br>
<div class="container center_div">
  <button class="btn btn-primary" type="submit">Pagar</button> 
</div>

</form>

</div>
</body>
</html>