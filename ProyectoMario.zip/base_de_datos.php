<?php

	$contraseña = "eduar123";
	$usuario = "id6854133_eduar";
	$BDName = "id6854133_bestgym";
	try{
		$BD = new PDO('mysql:host=localhost;dbname=' . $BDName, $usuario, $contraseña);
		// "Conexion exitosa";
	}catch (Exception $e){
		//echo "Ocurrio algo con la base de datos: " . $e->getMessage();
	}
	?>
